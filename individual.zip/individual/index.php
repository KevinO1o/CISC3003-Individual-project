<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>HOME</title>
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="font/font-awesome/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="css/style.css">
<script src="js/jquery.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
</head>

<body>
<div class="container-fluid">
  <header> 
    <!--<div class="text-right p-2 white"><a href="reg.html">Register</a> | <a href="reg.html?a=login">Log in</a></div>-->
    <nav class="navbar navbar-expand-sm navbar-dark container"> 
      <!-- Brand --> 
      <a class="navbar-brand" href="#"></a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar"> <span class="navbar-toggler-icon"></span> </button>
      <!-- Links -->
      <div class="collapse navbar-collapse" id="collapsibleNavbar">
        <ul class="navbar-nav bg-nav" style="width:100%" >
          <li class="nav-item"><a class="nav-link" href="index.php">HOME</a></li>
          <li class="nav-item"><a class="nav-link" href="about.php">ABOUT</a></li>
          <li class="nav-item"><a class="nav-link" href="product.php">PRODUCT</a></li>
          <li class="nav-item"><a class="nav-link" href="customization.php">Customization</a></li>
          <li class="nav-item">
            <?php
              if (!isset($_SESSION)) {
                  session_start();
              }
              if(isset($_SESSION['home_user'])){ ?>
            <span class="login nav-link">Hello，<?php echo $_SESSION['home_user'];?></span>
            <?php  }else{ ?>
            <a href='reg.html?a=login' class="nav-link">Login/Register</a>
            <?php } ?>
          </li>
        </ul>
      </div>
    </nav>
  </header>
  <div id="demo" class="carousel slide" data-ride="carousel"> 
    
    <!-- 指示符 -->
    <ul class="carousel-indicators">
      <li data-target="#demo" data-slide-to="0" class="active"></li>
      <li data-target="#demo" data-slide-to="1"></li>
      <li data-target="#demo" data-slide-to="2"></li>
    </ul>
    
    <!-- 轮播图片 -->
    <div class="carousel-inner" >
      <div class="carousel-item active"> <img src="img/banner1.jpg" class="img-fluid" width="100%"> </div>
      <div class="carousel-item"> <img src="img/banner2.jpg" class="img-fluid"  width="100%"> </div>
      <div class="carousel-item"> <img src="img/banner3.jpg" class="img-fluid"  width="100%"> </div>
    </div>
    
    <!-- 左右切换按钮 --> 
    <a class="carousel-control-prev" href="#demo" data-slide="prev"> <span class="carousel-control-prev-icon"></span> </a> <a class="carousel-control-next" href="#demo" data-slide="next"> <span class="carousel-control-next-icon"></span> </a> </div>
  <div class="jumbotron bg-light">
    <h2 align="center">Your skin, we take care of it with professional experience</h2>
    <p>Whiteheads? Hormonal Pimples? Dark Spots? Choose the patch for your blemish type with our collection of blemish patches for all kinds of blemishes.</p>
    <p> The hydrocolloid based patches help absorb gunk while keeping the skin protected from irritants and finger-picking</p>
    <p><a class="btn btn-primary" href="about.php" role="button">Learn more</a></p>
  </div>
  <div class="product">
    <h2 align="center">Commodity classification</h2>
    <div class="row space">
      <div class="col-lg-3 col-md-6 text-center"><a href="product.php"><img src="img/p1.jpg" class="img-fluid"></a>
        <h3><a href="product.php">Cleansing</a></h3>
      </div>
      <div class="col-lg-3 col-md-6  text-center"><a href="product.php"><img src="img/p5.jpg" class="img-fluid"></a>
        <h3><a href="product.php">face cream</a></h3>
      </div>
      <div class="col-lg-3  col-md-6 text-center"><a href="product.php"><img src="img/p2.jpg" class="img-fluid"></a>
        <h3><a href="product.php">lipstick</a></h3>
      </div>
      <div class="col-lg-3 col-md-6  text-center"><a href="product.php"><img src="img/p6.jpg" class="img-fluid"></a>
        <h3><a href="product.php">Eye black</a></h3>
      </div>
    </div>
  </div>
  <div class="parallax-img">
    <h2 align="center" style=" color:#fff;">OUR SERVICES</h2>
    <p class="container">We will choose the product that suits you from a variety of skincare products. Due to each person's unique skin, Clarins offers products with different textures, allowing you to consult and tailor recommendations based on age, skin type, preferred texture, and season.</p>
    <div class="text-center order"><a class="btn btn-primary" href="about.php" role="button">Customization</a></div>
  </div>
  <div class="new-pro">
    <h2 align="center">new arrival</h2>
    <div class="row">
      <div class="col-lg-6 pic"><a href="#" class="image"><img src="img/work-1.png" class="img-fluid" ></a></div>
      <div class="col-lg-6 des">
        <h2>DHC Olive lipstick</h2>
        <p>Strict selection of Andalusia, Spain
          Planting high-quality and tender olives from famous families,
          Artificial picking does not damage the original beauty ingredients in olives,
          Gathering only the flowers of olive oil that naturally drip,
          Can form a natural sebum film on the lips,
          Always protect delicate lips.</p>
      </div>
    </div>
    <div class="row">
      <div class="col-lg-6 des des2">
        <h2>Olive Nourishing Series</h2>
        <p>DHC Olive Makeup Remover has excellent makeup removal power, helping to remove makeup, clean pores, dirt, and aged keratin. DHC Olive Makeup Remover contains natural beauty ingredients, which can remove makeup without excessively depriving the skin of necessary moisture. After washing, it is hydrated and smooth.</p>
      </div>
      <div class="col-lg-6 pic"><a href="#" class="image-2"><img src="img/work-2.jpg" class="img-fluid"></a></div>
    </div>
    <div class="row">
      <div class="col-lg-6 pic"><a href="#" class="image"><img src="img/work-3.jpg" class="img-fluid"></a></div>
      <div class="col-lg-6 des">
        <h2>Youth and Beauty Collection</h2>
        <p>Kam fruit is rich in vitamin C
          Content up to 2000-3000mg * 1/100g
          About 37-56 times that of lemons * 2
          (Lemon has a VC content of 53mg * 3/100g)
          Removing freckles and whitening, leaving the skin hydrated and fair</p>
      </div>
    </div>
  </div>
  <div class="link container">
    <div class="row">
      <div class="col-sm-5 hidden-xs hidden-sm hidden-md">
        <h2>Quick Links</h2>
        <?php include('link.php');?>
      </div>
      <div class="col-sm-7">
        <h2>Contact Information</h2>
        <ol class="list-unstyled">
          <li  class="py-2"> Address：2063 RM, FE4，BD,DAXUEDAMALU ROAD,UNIVERSITY OF MACAU</li>
          <li class="py-2">Tel：+ 447419410529</li>
          <li class="py-2">Myblog-Summerproject：<a href="#">Myblog-Summerproject</a></li>
          <li class="py-2">Email：abc12345678@yahu.com</li>
          <li class="text-right py-2"><a href="https://twitter.com/edinburghuni" target="_blank"><i class="fa fa-twitter-square"></i></a><a href="https://m.facebook.com/ECA.edinburgh/" target="_blank"><i class="fa fa-facebook-square" aria-hidden="true"></i></a><a href="https://www.instagram.com/changwang670/" target="_blank"><span class="fa fa-instagram"></span></a></li>
        </ol>
      </div>
    </div>
  </div>
  <footer>
    <div class="text-center p-2 text-light">CISC3003 DC12824 ZENG JIANHENG<i class="
glyphicon glyphicon-heart"></i></div>
  </footer>
</div>
<script>
$(function(){
    $(".new-pro .image,.new-pro .image-2").hover(function(){
        $(this).animate({top:"-20px"},500); /* 500是动画过渡时间 */
    }, function(){
      $(this).animate({top:"0px"},100); /* 500是动画过渡时间 */
    })
});
</script>
</body>
</html>
