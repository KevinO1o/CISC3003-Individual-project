<?php

	//Clear the value in the session
	if (!isset($_SESSION)) {
	    session_start();//
	}
	unset($_SESSION['home_user']);
	@session_destroy();
	echo "<script>window.location.href='index.php'</script>";