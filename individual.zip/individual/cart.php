<?php
include('config/dbconfig.php');
if(!isset($_SESSION['home_user'])){
    echo "<script>alert('Not logged in, please login first！');location.href='login.php'</script>";
    exit;
}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>CART</title>
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="font/font-awesome/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="css/style.css">
<script src="js/jquery.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
</head>

<body>
<div class="container-fluid">
  <header  class="bg">
    <nav class="navbar navbar-expand-sm navbar-dark container"> 
      <!-- Brand --> 
      <a class="navbar-brand" href="#"></a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar"> <span class="navbar-toggler-icon"></span> </button>
      <!-- Links -->
      <div class="collapse navbar-collapse" id="collapsibleNavbar">
          <?php include('header.php');?>
      </div>
    </nav>
  </header>



 <div class="inner-cart container ">

    <table class="table table-hover">
<tr class="success"><th class="c-none">Picture</th><th>Name</th><th>Price</th><th>Number</th><th  class="c-none">Total</th><th>Operate</th></tr>
        <?php
        $sql = 'select c.*,g.* from cart as c
          left join goods as g on c.gid=g.gid
          where g.status=1 and username="'.$_SESSION['home_user'].'" order by cid desc';
        $result = mysqli_query($link,$sql) or die('Database operation failed：'.mysqli_error($link));
        $totalPrice=0;
        while($row = mysqli_fetch_assoc($result)){
            $totalPrice+=$row['price']*$row['num'];
        ?>
<tr><td  class="c-none"><img src="admin/include/uploads/<?php echo $row['pic'];?>" width="100"></td><td><?php echo $row['gname'];?></td><td><span id='unit_price<?php echo $row['cid'];?>'><?php echo $row['price'];?></span></td><td>  <a href="javascript:minusOne('<?php echo $row['cid'];?>');" class="tl"> <img src="img/gwc_9.jpg" /></a>
        <input name="num<?php echo $row['cid'];?>" type="text" readonly class="text04" id="num<?php echo $row['cid'];?>" onblur="updateNum(<?php echo $row['cid'];?>)" value="<?php echo $row['num'];?>" />
        <a href="javascript:addOne('<?php echo $row['cid'];?>');" class="tl"> <img src="img/gwc_10.jpg" /></a></td><td  class="c-none">$<span id='total_price<?php echo $row['cid'];?>'><?php echo $row['price']*$row['num'];?></span></td></td><td><a href="javascript:removeRow(<?php echo $row['cid'];?>);">Remove</a></td></tr>

        <?php }

        ?>
</table>
     <div class="text-right cart-price">Total Price:<span id="total"><?php echo $totalPrice;?></span><br><button class="btn white" onclick="location.href='action/action.php?a=order'">Buy Now</button></div>
  </div>

  <footer>
    <div class="text-center p-2 text-light">CISC3003 DC12824 ZENG JIANHENG <i class="
glyphicon glyphicon-heart"></i></div>
  </footer>
</div>
<script>
    function addOne(objId){
        let num=parseInt($('#num'+objId).val())+1;
        let price=+$('#unit_price'+objId).text();
        $.post("action/action.php?a=updatenum",{cid:objId,num:num},function(data){
            if (data.code==0) {
                $('#num'+objId).val(num);
                $('#total_price'+objId).text(num*price);
                $("#total").text(+$("#total").text()+price);
            }else{
                alert(data.msg);
            }
        },"json");
    }
    function minusOne(objId){
        let num=parseInt($('#num'+objId).val())-1;
        if (num<1) {
            return;
        }
        let price=+$('#unit_price'+objId).text();
        $.post("action/action.php?a=updatenum",{cid:objId,num:num},function(data){
            if (data.code==0) {
                $('#num'+objId).val(num);
                $('#total_price'+objId).text(num*price);
                $("#total").text(+$("#total").text()-price);
            }else{
                alert(data.msg);
            }
        },"json");
    }

  function addShop() {
    let buyNum = +$("#buy-num").val();
    let gid = +$("#gid").val();
    window.location.href = 'action/action.php?a=cart&gid='+gid+'&num='+buyNum;
  }
  function removeRow(objId){
      if (confirm('Are you sure you want to delete this product？')) {
          window.location.href='action/action.php?a=delcart&cid='+objId;
      }
  }

</script>
</body>
</html>
