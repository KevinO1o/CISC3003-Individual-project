﻿<?php
	@header("Content-type: text/html; charset=utf-8");//Set character set
	date_default_timezone_set('PRC'); //Set time zone
	if (!isset($_SESSION)) {
	    session_start();
	}

	//Database configuration file
	define("HOST", "localhost");
	define("USER", "root");
	define("PASS", "zjh667551");
	define("DBNAME", "glamify");

	//Linked database
	$link = @mysqli_connect(HOST,USER,PASS) or die('Database connection failed, check configuration information！');
	mysqli_select_db($link, DBNAME) or die('Database selection failed：'.mysqli_error($link));
	mysqli_set_charset($link, 'utf8'); //Set character set