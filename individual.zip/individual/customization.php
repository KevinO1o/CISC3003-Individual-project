<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>CUSTOMIZATION</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="font/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <script src="js/jquery.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
</head>

<body>
<div class="container-fluid">
    <header class="bg">
        <nav class="navbar navbar-expand-sm navbar-dark container">
            <!-- Brand -->
            <a class="navbar-brand" href="#"></a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar"><span
                        class="navbar-toggler-icon"></span></button>
            <!-- Links -->
            <div class="collapse navbar-collapse" id="collapsibleNavbar">
                <?php include('header.php'); ?>
            </div>
        </nav>
    </header>
    <div class="container inner-customization">
        <h1 class="text-center">Set customization</h1>
        <div class="row border-bottom p-5" id="row1">
            <div class="col-lg-6  text-center"><img src="img/d1_1.png" class="img-fluid" id="img1">
                <h3>Price：$120</h3>
            </div>
            <div class="col-lg-6 text-center">
                <a href="javascript:order1('d1_1')" data-name="Perfume suit" class=" normal choose" id="d1_1"><img
                            src="img/d1_1.png" width="100"><br>Perfume suit</a><br class="d-lg-block d-md-none">
                <a href="javascript:order1('d1_2')" class="normal " id="d1_2" data-name="Pink Honey Set"><img
                            src="img/d1_2.png" width="100"><br>Pink Honey Set</a><br class="d-lg-block d-md-none">
                <a href="javascript:order1('d1_3')" class="normal " id="d1_3" data-name="California Girls"><img
                            src="img/d1_3.png" width="100"><br>California Girls</a></div>
            <div class="m-auto">
                <button class="btn  btn-primary" onclick="orderEarring()">OK</button>
            </div>
        </div>


        <div class="row  p-5" id="row3">
            <div class="col-lg-6  text-center"><img src="img/d3_1.png" class="img-fluid" id="img3">
                <h3>Price：$180</h3>
            </div>
            <div class="col-lg-6 text-center">

                <a href="javascript:order3('d3_1','180')" id="d3_1" data-name="Naked Sundays"
                   class="normal2 choose"><img src="img/d3_1.png" width="100">Naked Sundays</a><br>
                <a href="javascript:order3('d3_2','100')" class="normal2" id="d3_2" data-name="Summer Skincare"><img
                            src="img/d3_2.png" width="100">Summer Skincare</a> <a href="javascript:order3('d3_3','200')"
                                                                                  id="d3_3" class="normal2 "  data-name="Water tender set"><img
                            src="img/d3_3.png" width="100" >Water tender set</a><br>
            </div>
            <div class="m-auto">
                <button class="btn btn-primary" onclick="orderBrooch()">OK</button>
            </div>
        </div>
    </div>

    <div class="bgpink">
        <div class="inner-link container ">
            <div class="row">
                <div class="col-sm-5">
                    <h2>Quick Links</h2>
                    <?php include('link.php'); ?>
                </div>
                <div class="col-sm-7">
                    <h2>Contact Information</h2>
                    <ol class="list-unstyled">
                        <li class="py-2"> Address：2063 RM, FE4，BD,DAXUEDAMALU ROAD,UNIVERSITY OF MACAU</li>
                        <li class="py-2">Tel：+ 447419410529</li>
                        <li class="py-2">Myblog-Summerproject：<a href="#">Myblog-Summerproject</a></li>
                        <li class="py-2">Email：abc12345678@yahu.com</li>
                        <li class="text-right py-2"><a href="https://twitter.com/edinburghuni" target="_blank"><i
                                        class="fa fa-twitter-square"></i></a><a
                                    href="https://m.facebook.com/ECA.edinburgh/" target="_blank"><i
                                        class="fa fa-facebook-square" aria-hidden="true"></i></a><a
                                    href="https://www.instagram.com/changwang670/" target="_blank"><span
                                        class="fa fa-instagram"></span></a></li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
    <footer>
        <div class="text-center p-2 text-light">CISC3003 DC12824 ZENG JIANHENG<i class="
glyphicon glyphicon-heart"></i></div>
    </footer>
</div>
<script>
    function order1(imgsrc) {
        $("#img1").attr("src", "img/" + imgsrc + ".png");
        $("#" + imgsrc).siblings("a").removeClass("choose");
        $("#" + imgsrc).addClass("choose");
    }

    function order3(imgsrc, price) {
        $("#img3").attr("src", "img/" + imgsrc + ".png");
        $("#" + imgsrc).siblings("a").removeClass("choose");
        $("#" + imgsrc).addClass("choose");
        $("#row3 h3").text('Price：$' + price);
    }


    function orderEarring() {
        let material = $("#row1 .choose").attr("data-name");
        let con = "Price：$120";
        window.location.href = 'action/action.php?a=message&title=' + material + '&content=' + con;
    }

    function orderBrooch() {
        let material = $("#row3 .choose").attr("data-name");
        let con = $("#row3 h3").text();
        window.location.href = 'action/action.php?a=message&title=' + material + '&content=' + con;
    }

</script>
</body>
</html>
