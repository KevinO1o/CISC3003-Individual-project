<?php
	include("../config/dbconfig.php");
	if (!isset($_GET['a'])) {
		echo "<script>window.history.go(-1);</script>";
		exit;
	}

	function filterStr($param){
        $param = str_replace("'", '', $param);
        $param = str_replace("&#039;", '', $param);
        $param = str_replace("&apos;", '', $param);
        $param = str_replace("\\", '', $param);
        $param = str_replace("#", '', $param);
        return $param;
    }

	if (!isset($_SESSION) || !isset($_SESSION['home_user'])) {
		echo "<script>alert('Please log in first！');location.href='../reg.html?a=login.php'</script>";
        exit;
	}

	switch ($_GET['a']) {
		case 'cart': // add cart
			if (!isset($_GET['gid'])) {
				echo "<script>alert('Product ID value transfer error！');window.history.go(-1);</script>";
				exit;
			}
			if (!isset($_GET['num'])) {
				$num = 1;
			}else{
				$num = intval($_GET['num']);
			}
			// If yes, it will be updated; if not, it will be inserted
			$sql = "insert into cart(username,gid,num) values('{$_SESSION['home_user']}', {$_GET['gid']}, {$num}) 
					 on duplicate key update num=num+{$num}";
			$result =  mysqli_query($link,$sql) or die(mysqli_error($link));
			if ($result) {
				 echo "<script>location.href='../cart.php'</script>";
			}else{
				echo "<script>alert('Join failed！');window.history.go(-1);</script>";
			}
			break;

		case 'message': //Add order
			$title   = $_GET['title'];
			$content = $_GET['content'];
		    $sql = "insert into messages(name,title,content) values('{$_SESSION['home_user']}', '$title', '$content')";
			$result =  mysqli_query($link,$sql) or die(mysqli_error($link));
			if (mysqli_insert_id($link)>0) {
				echo "<script>alert('Customized successfully！');location.href='../customization.php'</script>";
			}else{
				echo "<script>alert('Customization failed！');location.href='../customization.php'</script>";
			}
			break;

		case 'delcart': // Delete cart item
			if (!isset($_GET['cid'])) {
				echo "<script>alert('传值错误！');window.history.go(-1);</script>";
				exit;
			}
			$sql = "delete from cart where cid=".$_GET['cid'];
			$result =  mysqli_query($link,$sql) or die(mysqli_error($link));
			echo "<script>location.href='../cart.php'</script>";
			break;

        case 'updatenum': // Modify cart quantity
            $sql = "update cart set num={$_POST['num']} where cid=".$_POST['cid'];
            $result = mysqli_query($link,$sql);
            if ($result) {
                echo json_encode(array('code'=>0));
            }else{
                echo json_encode(array('code'=>999,'msg'=>mysqli_error($link)));
            }
            break;

		case 'order': // place order


			$cSql = "select * from cart where username='{$_SESSION['home_user']}'";
			$cResult =  mysqli_query($link,$cSql) or die(mysqli_error($link));
			$gidArr = array();
			$buyNum = array();
			while ($cRow = mysqli_fetch_assoc($cResult)) {
				$gidArr[] = $cRow['gid'];
				$buyNum[$cRow['gid']] = $cRow['num'];
			}
			$gidstr = implode(',',$gidArr);

			//Find order information
			$gSql = "select gid,gname,price,pic from goods where gid in ({$gidstr})";
			$gResult =  mysqli_query($link,$gSql) or die(mysqli_error($link));
			$goodsInfo = array();
			$key = 0;
			$total_price = 0; //Total price of goods
			while ($gRow = mysqli_fetch_assoc($gResult)) {
				$total_price = $total_price+($gRow['price']*$buyNum[$gRow['gid']]);
				$goodsInfo[] = array('gid'=>$gRow['gid'],'gname'=>$gRow['gname'],'price'=>$gRow['price'],'pic'=>$gRow['pic'],'num'=>$buyNum[$gRow['gid']]);
				$key++;
			}
			$content = addslashes(json_encode($goodsInfo)); //Order item information
			$order_id = date('Ymd').substr(implode(NULL, array_map('ord', str_split(substr(uniqid(), 7, 13), 1))), 0, 8); //Generate order number
			
			// Order warehousing
			$sql = "insert into `order`(order_id,username,total_price,content) 
					values('{$order_id}','{$_SESSION['home_user']}',{$total_price},'{$content}')";
			$result =  mysqli_query($link,$sql) or die(mysqli_error($link));
			if (mysqli_insert_id($link)>0) {
				//If the order is successful, the goods corresponding to the shopping cart will be deleted
				$dSql = "delete from cart where username='{$_SESSION['home_user']}'";
				$dResult =  mysqli_query($link,$dSql) or die(mysqli_error($link));
				echo "<script>alert('checkout success！');location.href='../index.php'</script>";
			}else{
				echo "<script>alert('Order failed, please try again！');window.history.go(-1)</script>";
			}
			break;
			
	}
	
	//close database
	mysqli_close($link);