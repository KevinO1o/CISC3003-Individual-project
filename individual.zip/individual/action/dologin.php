<?php
	include('../config/dbconfig.php');

	switch ($_GET['a']) {
		case 'login': //login
            //Receiving account and password
            $name = $_POST['name']; //account
            $pwd1  = $_POST['loginPwd']; //password
            if($name == ''){
                echo "<script>alert('The user name cannot be empty！');history.go(-1)</script>";
                exit;
            }
            if($pwd1 == ''){
                echo "<script>alert('Password cannot be empty！');history.go(-1)</script>";
                exit;
            }

			$sql = "select username,password from members where username='{$name}'";
			$result = mysqli_query($link,$sql) or die(mysqli_error($link));;

			if($result && mysqli_num_rows($result)>0){//User presence
				$row = mysqli_fetch_assoc($result);
				if($pwd1 != $row['password']){//Judge password
					echo "<script>alert('Wrong password, please re-enter！');history.go(-1)</script>";
					exit;
				}
				$_SESSION['home_user'] = $row['username'];
				echo "<script>alert('Successful landing！');location.href='../index.php'</script>";
			}else{//user name不存在
			    echo "<script>alert('The user name does not exist, please re-enter！');history.go(-1)</script>";
			}

			break;
		
		case 'register'://register
            //Receiving account and password
            $name = $_POST['name']; //account
            $email = $_POST['email']; //email
            $pwd1  = $_POST['password']; //password
            $pwd2 = $_POST['password2'];
            if($name == ''){
                echo "<script>alert('The user name cannot be empty！');history.go(-1)</script>";
                exit;
            }
            if($email == ''){
                echo "<script>alert('Email cannot be empty！');history.go(-1)</script>";
                exit;
            }

            if($pwd1 == ''){
                echo "<script>alert('Password cannot be empty！');history.go(-1)</script>";
                exit;
            }

            if(!preg_match("/^[a-zA-Z0-9]{4,16}$/", $pwd1)){
                echo "<script>alert('Please enter a 4-16 digit password！');history.go(-1)</script>";
                exit;
            }

			if(!preg_match("/^[a-zA-Z0-9]{4,16}$/", $pwd2)){
				echo "<script>alert('Please enter a 4-16 digit password！');history.go(-1)</script>";
				exit;
			}
			if ($pwd1 != $pwd2) {
				echo "<script>alert('The two passwords are inconsistent, please re-enter！');history.go(-1)</script>";
				exit;
			}
			
		    $selSql = "select id from members where username='{$name}'";
			$selResult = mysqli_query($link,$selSql) or die(mysqli_error($link));

			if($selResult && mysqli_num_rows($selResult)>0){//User presence
				echo "<script>alert('The user name already exists. Please replace it with a new one！');history.go(-1)</script>";
				exit;
			}

			$date = date('Y-m-d H:i:s');

	        $insSql = "insert into members values(null,'$name', '$pwd1','$email', '$date')";
			$result =  mysqli_query($link,$insSql) or die(mysqli_error($link));;
			if (mysqli_insert_id($link)>0) {
				echo "<script>alert('login was successful！');location.href='../reg.html?a=login'</script>";
			}else{
				echo "<script>alert('login has failed！');history.go(-1)</script>";
			}
			break;

		case 'updpass':
			if ($_POST['pwd1']!=$_POST['pwd2']) {
				echo "<script>alert('The two passwords are inconsistent, please re-enter！');history.go(-1)</script>";
				exit;
			}
			$sql = "update members set passwords='{$_POST['pwd1']}' where username='{$_SESSION['home_user']}'";
			$result =  mysqli_query($link,$sql) or die(mysqli_error($link));
			if ($result) {
				echo "<script>alert('Modification succeeded！');location.href='user.php'</script>";
			}else{
				echo "<script>alert('Modification failed！');window.history.go(-1)</script>";
			}
			break;
	}

	//Close the database to release the result set
	mysqli_close($link);