<?php 
  if (!isset($_SESSION)) {
      session_start();
  }
  if(!isset($_SESSION['admin_users'])){
    echo "<script>window.location.href='../login/login.php'</script>";
    exit;
}
?>
<!DOCTYPE html>
<html lang="zh-cn">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
<meta name="renderer" content="webkit">
<title></title>
<link rel="stylesheet" href="../include/css/pintuer.css">
<link rel="stylesheet" href="../include/css/admin.css">
<script src="../include/js/jquery.js"></script>
<script src="../include/js/pintuer.js"></script>
</head>
<body>
<div class="panel admin-panel">
  <div class="panel-head"><strong class="icon-reorder"> Classification information</strong></div>
  <div class="padding border-bottom">
    <button type="button" class="button border-yellow" onclick="window.location.href='type_add.php'"><span class="icon-plus-square-o"></span> Add category</button>
  </div>
  <table class="table table-hover text-center">
    <tr>
      <th width="5%">ID</th>
      <th width="15%">Primary classification</th>
      <th width="10%">sort</th>
      <th width="10%">operation</th>
    </tr>
    <?php
      //Connect to database
      include('../../config/dbconfig.php');
      $sql = "select * from type order by sort asc,tid desc";
      $result = mysqli_query($link,$sql) or die('Database operation failed：'.mysqli_error($link));
      //Display the data in the table
    $index = 1;
          while($row = mysqli_fetch_assoc($result)){
            echo "<tr>
              <td>".($index++)."</td>
          <td>{$row['tname']}</td>
          <td>{$row['sort']}</td>
          <td><div class=\"button-group\"> <a class=\"button border-main\" href=\"type_edit.php?tid={$row['tid']}\"><span class=\"icon-edit\"></span> edit</a> 
              <a class=\"button border-red\" href=\"javascript:del({$row['tid']})\"><span class=\"icon-trash-o\"></span> delete</a> </div></td>
        </tr>";
        }
      ?> 
  </table>
</div>
<script type="text/javascript">
function del(id){
	if(confirm("Are you sure you want to delete it?")){
    window.location.href='type_action.php?a=del&tid='+id;
	}
}
</script>
</body>
</html>