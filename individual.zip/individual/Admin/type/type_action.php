<?php
	include("../../config/dbconfig.php");

	switch($_GET['a']){
		case 'add':
			if (!$_POST['name']) {
				echo "<script>alert('Please enter Classification name');history.go(-1)</script>";
				exit;
			}
			if (!$_POST['sort']) {
				$_POST['sort'] = 100;
			}
			//Verify that the classification already exists in the database
			$sql = "select * from type where tname='{$_POST['name']}'";
			$result = mysqli_query($link, $sql) or die('Database operation failed：'.mysqli_error($link));
			if($result && mysqli_num_rows($result)>0){//Category already exists
				echo "<script>alert('The classification name already exists, please re-enter！');history.go(-1)</script>";
			}else{
				$insSql = "insert into type(tname,sort) value('{$_POST['name']}',{$_POST['sort']})";
				$insResult = mysqli_query($link, $insSql) or die('Database operation failed：'.mysqli_error($link));
				if (mysqli_insert_id($link)) {
					echo "<script>alert('Added successfully！');window.location.href='type_list.php'</script>";
				}else{
					echo "<script>alert('Add failed！');window.history.go(-1)</script>";
				}
			}
			break;
					
		case 'del':
			$sql = "delete from type where tid=".$_GET['tid'];
			$result = mysqli_query($link,$sql) or die('Database operation failed：'.mysqli_error($link));
			if(mysqli_affected_rows($link)){
				echo "<script>alert('Delete succeeded！');window.location.href='type_list.php'</script>";
			}else{
				echo "<script>alert('Delete failed！');history.go(-1)</script>";
			}
			break;
		case 'update':
			if (!$_POST['tname']) {
				echo "<script>alert('Please enter Classification name');history.go(-1)</script>";
				exit;
			}
			if (!$_POST['sort']) {
				$_POST['sort'] = 100;
			}
			//Verify that the classification already exists in the database
			$sql = "select tid from type where tname='{$_POST['tname']}' and tid!=".$_POST['tid'];
			$result = mysqli_query($link, $sql) or die('Database operation failed：'.mysqli_error($link));
			if($result && mysqli_num_rows($result)>0){//Category already exists
				echo "<script>alert('The classification name already exists, please re-enter！');history.go(-1)</script>";
			}else{
				$sql = "update type set tname='{$_POST['tname']}',sort={$_POST['sort']} where tid=".$_POST['tid'];
				$result = mysqli_query($link,$sql) or die('Database operation failed：'.mysqli_error($link));
				if ($result) {
					echo "<script>alert('Modification succeeded！');window.location.href='type_list.php'</script>";
				}else{
					echo "<script>alert('Modification failed！');history.go(-1)</script>";
				}
			}
			break;
	}
	//Close the database to release the result set
	if (isset($result)) {
		@mysqli_free_result($result);	
	}
	@mysqli_close($link);