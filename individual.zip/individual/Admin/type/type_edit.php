<?php 
  //Import profile
  include('../../config/dbconfig.php'); 
  if(!isset($_SESSION['admin_users'])){
    echo "<script>window.location.href='../login/login.php'</script>";
    exit;
  }
  if (!isset($_GET['tid'])) {
    echo "<script>window.history.go(-1)</script>";
    exit;
  }
   $sql = "select * from type where tid=".$_GET['tid'];
   $result = mysqli_query($link,$sql) or die('Database operation failed：'.mysqli_error($link));;
   $row = mysqli_fetch_assoc($result);
?>
<!DOCTYPE html>
<html lang="zh-cn">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
<meta name="renderer" content="webkit">
<title></title>
<link rel="stylesheet" href="../include/css/pintuer.css">
<link rel="stylesheet" href="../include/css/admin.css">
<script src="../include/js/jquery.js"></script>
<script src="../include/js/pintuer.js"></script>
</head>
<body>
<div class="panel admin-panel margin-top">
  <div class="panel-head" id="add"><strong><span class="icon-pencil-square-o"></span> Modify classification</strong></div>
  <div class="body-content">
    <form method="post" class="form-x" action="type_action.php?a=update">        
      <input type="hidden" class="input w50" name="tid" value="<?php echo $row['tid'];?>" />
      <div class="form-group">
        <div class="label">
          <label>Classification name：</label>
        </div>
        <div class="field">
          <input type="text" class="input w50" name="tname" value="<?php echo $row['tname'];?>" />
          <div class="tips"></div>
        </div>
      </div>
      <div class="form-group">
        <div class="label">
          <label>sort：</label>
        </div>
        <div class="field">
          <input type="text" class="input w50" name="sort" value="<?php echo $row['sort'];?>"  data-validate="number:Sort must be numeric" />
          <div class="tips"></div>
        </div>
      </div>
      <div class="form-group">
        <div class="label">
          <label></label>
        </div>
        <div class="field">
          <button class="button bg-main icon-check-square-o" type="submit"> submit</button>
        </div>
      </div>
    </form>
  </div>
</div>
</body></html>