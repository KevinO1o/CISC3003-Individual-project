<?php
  include("../../config/dbconfig.php");
  if(!isset($_SESSION['admin_users'])){
    echo "<script>window.location.href='../login/login.php'</script>";
    exit;
  }
  if(!isset($_GET['gid'])){
    echo "<script>window.history.go(-1);</script>";
    exit;
  }
  $sql = "select * from goods where gid = ".$_GET['gid'];
  $result = mysqli_query($link,$sql) or die('Database operation failed：'.mysqli_error($link));
  $goodsInfo = mysqli_fetch_assoc($result);
?>
<!DOCTYPE html>
<html lang="zh-cn">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
<meta name="renderer" content="webkit">
<title></title>
<link rel="stylesheet" href="../include/css/pintuer.css">
<link rel="stylesheet" href="../include/css/admin.css">
<script src="../include/js/jquery.js"></script>
<script src="../include/js/pintuer.js"></script>
<script src="../include/js/wangEditor.min.js"></script>
<style>
  [class*='icon-']:before {
   font-family: 'w-e-icon' !important;
  }
</style>
</head>
<body>
<div class="panel admin-panel margin-top">
  <div class="panel-head" id="add"><strong><span></span> Modify product</strong></div>
  <div class="body-content">
    <form method="post" class="form-x" action="good_action.php?a=update" enctype="multipart/form-data">
      <input type="hidden" name="gid" value="<?php echo $goodsInfo['gid'];?>">
      <div class="form-group">
        <div class="label">
          <label>Commodity classification：</label>
        </div>
        <div class="field">
          <select name="tid" class="input w50" data-validate="required:Please enter Commodity classification">
            <option value="">Please select a category</option>
            <?php
              $typeSql = "select * from type order by sort asc,tid desc";
              $tResult = mysqli_query($link,$typeSql) or die('Database operation failed：'.mysqli_error($link));
              while($typeList = mysqli_fetch_assoc($tResult)){
                echo '<option value="'.$typeList['tid'].'" '.($goodsInfo['tid']==$typeList['tid']?'selected':'').'>'.$typeList['tname'].'</option>';
              }
            ?>
          </select>
        </div>
      </div>
      <div class="form-group">
        <div class="label">
          <label>Trade name：</label>
        </div>
        <div class="field">
          <input type="text" class="input w50" name="gname" value="<?php echo $goodsInfo['gname'];?>" data-validate="required:Please enter Trade name" />
        </div>
      </div>
      <div class="form-group">
        <div class="label">
          <label>commodity price：</label>
        </div>
        <div class="field">
          <input type="text" class="input w50" name="price" value="<?php echo $goodsInfo['price'];?>" data-validate="required:Please enter commodity price" />
        </div>
      </div>
      <div class="form-group">
        <div class="label">
          <label>old Cover map：</label>
        </div>
        <div class="field">
          <a href="../include/uploads/<?php echo $goodsInfo['pic'];?>" target="_blank">
            <img src="../include/uploads/<?php echo $goodsInfo['pic'];?>" width="100" alt="Cover map">
          </a>
          <div class="tips">(Click on the picture to view the larger picture)</div>
        </div>
      </div>
      <div class="form-group" style="height: 100px;line-height: 100px;">
        <div class="label">
          <label>Cover map：</label>
        </div>
        <div class="field">
          <input type="hidden" class="input w50" name="oldpic" value="<?php echo $goodsInfo['pic'];?>" />
          <input type="file" class="input w50" name="pic" />
        </div>
      </div>
      <div class="form-group">
        <div class="label">
          <label>Commodity details：</label>
        </div>
        <div class="field">
          <input type="hidden" name="content" id="content" value="<?php echo htmlspecialchars($goodsInfo['content']);?>">
          <div id="detail"></div>
        </div>
      </div>
      <div class="form-group">
        <div class="label">
          <label>sort：</label>
        </div>
        <div class="field">
          <input type="text" class="input w50" name="sort" value="<?php echo $goodsInfo['sort'];?>"  data-validate="number:Sort must be numeric" />
          <div class="tips"></div>
        </div>
      </div>
      <div class="form-group">
        <div class="label">
          <label></label>
        </div>
        <div class="field">
          <button class="button bg-main " type="submit" id="submit"> submit</button>
        </div>
      </div>
    </form>
  </div>
</div>
</body>
</html>
<script>
  var E = window.wangEditor;
  var editor = new E('#detail');
  editor.customConfig.uploadImgShowBase64 = true;   // Save pictures with Base64
  editor.create();
  editor.txt.html(document.getElementById('content').value);
  document.getElementById('submit').addEventListener('click', function () {
    // Read HTML
    var editor_txt=editor.txt.html();
    document.getElementById('content').value=editor_txt;
  }, false);
</script>