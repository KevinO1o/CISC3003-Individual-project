<?php
  include("../../config/dbconfig.php");
  if(!isset($_SESSION['admin_users'])){
    echo "<script>window.location.href='../login/login.php'</script>";
    exit;
}
?>
<!DOCTYPE html>
<html lang="zh-cn">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
<meta name="renderer" content="webkit">
<title>Add item</title>
<link rel="stylesheet" href="../include/css/pintuer.css">
<link rel="stylesheet" href="../include/css/admin.css">
<script src="../include/js/jquery.js"></script>
<script src="../include/js/pintuer.js"></script>
<script src="../include/js/wangEditor.min.js"></script>
<style>
  [class*='icon-']:before {
   font-family: 'w-e-icon' !important;
  }
</style>
</head>
<body>
<div class="panel admin-panel margin-top">
  <div class="panel-head" id="add"><strong><span></span> Add item</strong></div>
  <div class="body-content">
    <form method="post" class="form-x" action="good_action.php?a=add" enctype="multipart/form-data">
      <div class="form-group">
        <div class="label">
          <label>Commodity classification：</label>
        </div>
        <div class="field">
          <select name="tid" class="input w50" data-validate="required:Please select Commodity classification">
            <option value="">Please select a category</option>
            <?php
              $typeSql = "select * from type order by sort asc,tid desc";
              $tResult = mysqli_query($link,$typeSql) or die('Database operation failed：'.mysqli_error($link));
              while($typeList = mysqli_fetch_assoc($tResult)){
                echo '<option value="'.$typeList['tid'].'">'.$typeList['tname'].'</option>';
              }
            ?>
          </select>
        </div>
      </div>
      <div class="form-group">
        <div class="label">
          <label>Trade name：</label>
        </div>
        <div class="field">
          <input type="text" class="input w50" name="gname" data-validate="required:Please enter Trade name" />
        </div>
      </div>
      <div class="form-group">
        <div class="label">
          <label>commodity price：</label>
        </div>
        <div class="field">
          <input type="text" class="input w50" name="price" data-validate="required:Please enter commodity price" />
        </div>
      </div>
      <div class="form-group">
        <div class="label">
          <label>Cover map：</label>
        </div>
        <div class="field">
          <input type="file" class="input w50" name="pic" data-validate="required:Please upload the product Cover map" />
        </div>
      </div>
      <div class="form-group">
        <div class="label">
          <label>Commodity details：</label>
        </div>
        <div class="field">
          <input type="hidden" name="content" id="content">
          <div id="detail"></div>
        </div>
      </div>
      <div class="form-group">
        <div class="label">
          <label>sort：</label>
        </div>
        <div class="field">
          <input type="text" class="input w50" name="sort" value="100"  data-validate="number:Sort must be numeric" />
          <div class="tips"></div>
        </div>
      </div>
      <div class="form-group">
        <div class="label">
          <label></label>
        </div>
        <div class="field">
          <button class="button bg-main " type="submit" id="submit"> submit</button>
        </div>
      </div>
    </form>
  </div>
</div>
</body>
</html>
<script>
  var E = window.wangEditor;
  var editor = new E('#detail');
  editor.customConfig.uploadImgShowBase64 = true;   // Save pictures with Base64
  editor.create();
  document.getElementById('submit').addEventListener('click', function () {
    // Read HTML
    var editor_txt=editor.txt.html();
    document.getElementById('content').value=editor_txt;
  }, false);
</script>