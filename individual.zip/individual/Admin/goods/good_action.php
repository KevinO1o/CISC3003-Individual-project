<?php
	include("../../config/dbconfig.php");
	include("../include/functions.php");

	switch($_GET['a']){
		case 'add':
			if (!$_POST['tid']) {
				echo "<script>alert('请选择Commodity classification');history.go(-1)</script>";
				exit;
			}
			if (!$_POST['gname']) {
				echo "<script>alert('Please enter Trade name');history.go(-1)</script>";
				exit;
			}
			if (!$_POST['price']) {
				echo "<script>alert('Please enter commodity price');history.go(-1)</script>";
				exit;
			}
			if (!$_POST['content']) {
				echo "<script>alert('Please enter Commodity details');history.go(-1)</script>";
				exit;
			}
			if (!$_POST['tid']) {
				echo "<script>alert('请选择Commodity classification');history.go(-1)</script>";
				exit;
			}
			if (!$_POST['sort']) {
				$_POST['sort'] = 100;
			}

			// Cover map上传
			$fileInfo = fileupload('../include/uploads/', $_FILES['pic']); //调用include文件夹里面的functions文件里的上传函数
			if (!$fileInfo['error']) {
				echo "<script>alert('".$fileInfo['info']."');history.go(-1)</script>";
				exit;
			}
			$pic = $fileInfo['info']; //上传后的图片名称
			
			$insSql = "insert into goods(tid,gname,price,pic,content,sort) 
					   value({$_POST['tid']},'{$_POST['gname']}',{$_POST['price']},'{$pic}','{$_POST['content']}',{$_POST['sort']})";
			$insResult = mysqli_query($link, $insSql) or die('Database operation failed：'.mysqli_error($link));
			if (mysqli_insert_id($link)) {
				echo "<script>alert('Added successfully！');window.location.href='good_list.php'</script>";
			}else{
				echo "<script>alert('Add failed！');window.history.go(-1)</script>";
			}
			break;
					
		case 'update':
			if (!$_POST['gid']) {
				echo "<script>alert('商品id未传值');history.go(-1)</script>";
				exit;
			}
			if (!$_POST['tid']) {
				echo "<script>alert('请选择Commodity classification');history.go(-1)</script>";
				exit;
			}
			if (!$_POST['gname']) {
				echo "<script>alert('Please enter Trade name');history.go(-1)</script>";
				exit;
			}
			if (!$_POST['price']) {
				echo "<script>alert('Please enter commodity price');history.go(-1)</script>";
				exit;
			}
			if (!$_POST['content']) {
				echo "<script>alert('Please enter Commodity details');history.go(-1)</script>";
				exit;
			}
			if (!$_POST['tid']) {
				echo "<script>alert('请选择Commodity classification');history.go(-1)</script>";
				exit;
			}
			if (!$_POST['sort']) {
				$_POST['sort'] = 100;
			}

			if ($_FILES['pic']['size']>0) { //如果上传了新的图片
				$fileInfo = fileupload('../include/uploads/', $_FILES['pic']); //调用include文件夹里面的functions文件里的上传函数
				if (!$fileInfo['error']) {
					echo "<script>alert('".$fileInfo['info']."');history.go(-1)</script>";
					exit;
				}
				$pic = $fileInfo['info']; //上传后的图片名称
			}else{
				$pic = $_POST['oldpic'];
			}

			$sql = "update goods set tid={$_POST['tid']},gname='{$_POST['gname']}',price={$_POST['price']},pic='{$pic}',content='{$_POST['content']}',sort={$_POST['sort']} where gid=".$_POST['gid'];
			$result = mysqli_query($link,$sql) or die('Database operation failed：'.mysqli_error($link));
			if ($result) {
				if ($pic != $_POST['oldpic']) { //如果上传了新图片，则delete原图片
					@unlink("../include/uploads/".$_POST['oldpic']);
				}
				echo "<script>alert('Modification succeeded！');window.location.href='good_list.php'</script>";
			}else{
				echo "<script>alert('Modification failed！');history.go(-1)</script>";
			}
			break;

		case 'del':
			$sql = "delete from goods where gid=".$_GET['gid'];
			$result = mysqli_query($link,$sql) or die('Database operation failed：'.mysqli_error($link));
			if(mysqli_affected_rows($link)){
				@unlink("../include/uploads/".$_GET['img']);//delete上传的图片
				echo "<script>alert('Delete succeeded！');history.go(-1)</script>";
			}else{
				echo "<script>alert('Delete failed！');history.go(-1)</script>";
			}
			break;

		case 'change':
			if (!$_GET['gid']) {
				echo "<script>alert('传值错误');history.go(-1)</script>";
				exit;
			}
			if (!isset($_GET['type'])) {
				echo "<script>alert('传值错误');history.go(-1)</script>";
				exit;
			}	
			$sql = "update goods set status={$_GET['type']} where gid=".$_GET['gid'];
			$result = mysqli_query($link,$sql) or die('Database operation failed：'.mysqli_error($link));
			if ($result) {
				echo "<script>alert('Modification succeeded！');history.go(-1)</script>";
			}else{
				echo "<script>alert('Modification failed！');history.go(-1)</script>";
			}
			break;
	}
	//Close the database to release the result set
	if (isset($result)) {
		@mysqli_free_result($result);	
	}
	@mysqli_close($link);