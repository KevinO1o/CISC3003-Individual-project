<?php 
  if (!isset($_SESSION)) {
      session_start();
  }
  if(!isset($_SESSION['admin_users'])){
    echo "<script>window.location.href='../login/login.php'</script>";
    exit;
}
?>
<!DOCTYPE html>
<html lang="zh-cn">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <meta name="renderer" content="webkit">
    <title></title>  
    <link rel="stylesheet" href="../include/css/pintuer.css">
    <link rel="stylesheet" href="../include/css/admin.css">
    <script src="../include/js/jquery.js"></script>
    <script src="../include/js/pintuer.js"></script>  
</head>
<body>
  <div class="panel admin-panel">
    <div class="panel-head"><strong class="icon-reorder"> Commodity information</strong></div>
    <div class="padding border-bottom">
    <form method="get" action="good_list.php">
      <ul class="search" style="padding-left:10px;">  
        <li>Trade name：</li>
        <li>
          <input type="text" placeholder="Please enter search keywords" name="name" value="<?php if(!empty($_GET['name'])){echo $_GET['name'];} ?>" class="input" style="width:250px; line-height:17px;display:inline-block" />
          <input type="submit" value="search" class="button border-main icon-search">
        </li>
      </ul>
      </form>
    </div>
    <table class="table table-hover text-center">
      <tr>
        <th width="120">ID</th>
        <th>Trade name</th>       
        <th>Commodity classification</th>       
        <th>commodity price</th>
        <th>Cover map</th>
        <th>Sort number</th>
        <th>state</th>
        <th>Add time</th>
        <th>operation</th>       
      </tr>  
      <?php
        //Connect to database
        include('../../config/dbconfig.php'); 
        $typeSql = "select * from type";
        $typeResult = mysqli_query($link,$typeSql) or die('Database operation failed：'.mysqli_error($link));
        $typeArr = array(); //分类数组
        while($typeRow = mysqli_fetch_assoc($typeResult)){
          $typeArr[$typeRow['tid']] = $typeRow['tname'];
        }

        //Accept search criteria information
        $wherelist = array();//Search criteria to database
        $urllist = array();//The search condition gives the URL the status maintenance

        //Determine whether the search criteria exist
        if(!empty($_GET['name'])){
            $wherelist[] = " gname like '%".$_GET['name']."%'";
            $urllist[] = "name={$_GET['name']}";
        }

        //Splicing search statements
        $where = "";
        $url = "";
        if(count($wherelist)>0){
          $where =  " where ".implode(' and ', $wherelist);
          $url = implode('&', $urllist);
        }

        // Paging settings
        $page = !empty($_GET['p']) ? $_GET['p'] : 1 ;//Specific page number
        $pagesize = 4;//Number of items per page
        $maxrow = 0;//How many messages are there
        $maxpage = 0;//How many pages are displayed

        //  How many messages are there
        $sql = "select gid from goods ".$where;
        $result = mysqli_query($link,$sql) or die('Database operation failed：'.mysqli_error($link));
        $maxrow = mysqli_num_rows($result);

        //  How many pages are there altogether 
        $maxpage = ceil($maxrow/$pagesize);  //Ceil is a rounding function

        //  Judge the validity of the page number
        if($page>$maxpage){
          $page = $maxpage;
        }
        if($page<1){
          $page = 1;
        }
        
        // Write SQL statement
        $limit = " limit ".($page-1)*$pagesize.",".$pagesize;
          //Splicing search and paging function
          $sql = "select * from goods ".$where.'order by status desc,sort desc,addtime desc '.$limit;
          $result = mysqli_query($link,$sql) or die('Database operation failed：'.mysqli_error($link));
          //Display the data in the table
        $index = 1;
          while($row = mysqli_fetch_assoc($result)){
            echo "<tr>
              <td>".(($page-1)*$pagesize+$index++)."</td>
              <td>{$row['gname']}</td>
              <td>{$typeArr[$row['tid']]}</td>
              <td>{$row['price']}</td>
              <td><img src=\"../include/uploads/{$row['pic']}\" alt=\"Cover map\" width=\"100\"></td>
              <td>{$row['sort']}</td>
              <td>".($row['status']==1?"On the shelf <a class=\"button border-main\" href=\"javascript:change({$row['gid']},0)\">Off the shelf</a>":"Off the shelf <a class=\"button border-main\" href=\"javascript:change({$row['gid']},1)\">On the shelf</a>")."</td>
              <td>{$row['addtime']}</td>
              <td>
                <div class=\"button-group\"> 
                  <a class=\"button border-green\" href=\"../../product-show.php?id={$row['gid']}\" target=\"_blank\"><span class=\"icon-reorder\"></span> view</a> 
                  <a class=\"button border-main\" href=\"good_edit.php?gid={$row['gid']}\"><span class=\"icon-edit\"></span> edit</a> 
                  <a class=\"button border-red\" href=\"javascript:del({$row['gid']},'{$row['pic']}')\"><span class=\"icon-trash-o\"></span> delete</a>
               </div>
              </td>
            </tr>";
          }
        ?> 
      <tr>
        <td colspan="8"><div class="pagelist"> 
          <?php
            echo "<a href='good_list.php?p=1&{$url}'>home page</a>";
            echo "<a href='good_list.php?p=".($page-1)."&{$url}'>previous page</a>";
            echo "<span class='current'>total{$maxrow} {$page}/{$maxpage} page</span>";
            echo "<a href='good_list.php?p=".($page+1)."&{$url}'>next page</a>";
            echo "<a href='good_list.php?p={$maxpage}&{$url}'>Last page</a>";
          ?>
        </div>
        </td>
      </tr>
    </table>
  </div>
<script type="text/javascript">
function del(id,img){
  if(confirm("Are you sure you want to delete it?")){
    window.location.href='good_action.php?a=del&gid='+id+'&img='+img;
  }
}

function change(id,type){
  let msg = 'On the shelf';
  if (type==0) msg = 'Off the shelf';
  if(confirm('Are you sure you want to '+msg+' this product?')){
    window.location.href='good_action.php?a=change&gid='+id+'&type='+type;
  }
}
</script>
</body>
</html>