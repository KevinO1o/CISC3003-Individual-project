<?php
	include('../../config/dbconfig.php');
	/*if ($_POST['code'] != $_SESSION['verify_code']) {
		echo "<script>alert('验证码错误，请重新输入！');history.go(-1)</script>";
		exit;
	}*/
	//接收传值
	$name = $_POST['name']; //帐号
	$pass = $_POST['password']; //密码

	//验证数据库里的账号 密码
	$sql = "select * from admin where username='{$name}'";
	$result = mysqli_query($link, $sql) or die('Database operation failed：'.mysqli_error($link));
	if($result && mysqli_num_rows($result)>0){//用户存在
		$row = mysqli_fetch_assoc($result);
		if($pass != $row['pass']){//判断密码
			echo "<script>alert('密码错误，请重新输入！');history.go(-1)</script>";
			exit;			
		}
		$_SESSION['admin_users'] = $row;
		echo "<script>window.location.href='../index.php'</script>";
	}else{//用户不存在
		echo "<script>alert('帐号不存在，请重新输入！');history.go(-1)</script>";
	}

	//Close the database to release the result set
	if (isset($result)) {
		@mysqli_free_result($result);	
	}
	@mysqli_close($link);