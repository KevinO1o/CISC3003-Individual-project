<?php
	//清空session里面的值
	if (!isset($_SESSION)) {
	    session_start();
	}
	unset($_SESSION['admin_users']);
	@session_destroy();
	echo "<script>window.location.href='login.php'</script>";