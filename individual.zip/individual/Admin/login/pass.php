<?php 
  if (!isset($_SESSION)) {
      session_start();
  }
  if(!isset($_SESSION['admin_users'])){
    echo "<script>window.location.href='../login/login.php'</script>";
    exit;
}
?>
<!DOCTYPE html>
<html lang="zh-cn">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
<meta name="renderer" content="webkit">
<title></title>
<link rel="stylesheet" href="../include/css/pintuer.css">
<link rel="stylesheet" href="../include/css/admin.css">
<script src="../include/js/jquery.js"></script>
<script src="../include/js/pintuer.js"></script>
</head>
<body>
<div class="panel admin-panel">
  <div class="panel-head"><strong><span class="icon-key"></span> Change Password</strong></div>
  <div class="body-content">
    <form method="post" class="form-x" action="updpass.php">
      <div class="form-group">
        <div class="label">
          <label for="sitename">Administrator account：</label>
        </div>
        <div class="field">
          <label style="line-height:33px;">
           <?php echo $_SESSION['admin_users']['username'];?>
          </label>
        </div>
      </div>      
      <div class="form-group">
        <div class="label">
          <label for="sitename">Original password：</label>
        </div>
        <div class="field">
          <input type="password" class="input w50" id="mpass" name="mpass" size="50" placeholder="Original password" data-validate="required:Original password" />       
        </div>
      </div>      
      <div class="form-group">
        <div class="label">
          <label for="sitename">New password：</label>
        </div>
        <div class="field">
          <input type="password" class="input w50" name="newpass" size="50" placeholder="New password" data-validate="required:New password,length#>=5:New password" />         
        </div>
      </div>
      <div class="form-group">
        <div class="label">
          <label for="sitename">Confirm new password：</label>
        </div>
        <div class="field">
          <input type="password" class="input w50" name="renewpass" size="50" placeholder="New password" data-validate="required:New password,repeat#newpass:The two passwords are not the same" />          
        </div>
      </div>
      
      <div class="form-group">
        <div class="label">
          <label></label>
        </div>
        <div class="field">
          <button class="button bg-main icon-check-square-o" type="submit"> submit</button>   
        </div>
      </div>      
    </form>
  </div>
</div>
</body></html>