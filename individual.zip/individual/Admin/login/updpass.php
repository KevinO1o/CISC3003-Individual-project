<?php
	include('../../config/dbconfig.php');
	
	//接收传值
	$mpass = $_POST['mpass']; //原密码
	$newpass = $_POST['newpass']; //New password
	$renewpass = $_POST['renewpass']; //重复New password
	if ($newpass!=$renewpass) {
		echo "<script>alert('The two passwords are different. Please re-enter them！');history.go(-1)</script>";
		exit;
	}

	//验证原密码
	$selSql = "select pass from admin where username='{$_SESSION['admin_users']['username']}'";
	$selResult = mysqli_query($link, $selSql) or die('Database operation failed：'.mysqli_error($link));
	$selRow = mysqli_fetch_assoc($selResult);
	if($mpass != $selRow['pass']){//判断密码
		echo "<script>alert('Please re-enter the old password');history.go(-1)</script>";
		exit;			
	}

	$sql = "update admin set pass='{$newpass}' where username='{$_SESSION['admin_users']['username']}'";
	$result = mysqli_query($link,$sql) or die('Database operation failed：'.mysqli_error($link));
	if ($result) {
		echo "<script>alert('Modification succeeded！');window.location.href='pass.php'</script>";
	}else{
		echo "<script>alert('Modification failed！');history.go(-1)</script>";
	}

	//Close the database to release the result set
	if (isset($result)) {
		@mysqli_free_result($result);	
	}
	@mysqli_close($link);