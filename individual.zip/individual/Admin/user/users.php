<?php 
  if (!isset($_SESSION)) {
      session_start();// Open session
  }
  if(!isset($_SESSION['admin_users'])){
    echo "<script>window.location.href='../login/login.php'</script>";
    exit;
}
?>
<!DOCTYPE html>
<html lang="zh-cn">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <meta name="renderer" content="webkit">
    <title></title>  
    <link rel="stylesheet" href="../include/css/pintuer.css">
    <link rel="stylesheet" href="../include/css/admin.css">
    <script src="../include/js/jquery.js"></script>
    <script src="../include/js/pintuer.js"></script>  
</head>
<body>
  <div class="panel admin-panel">
    <div class="panel-head"><strong class="icon-reorder"> Member information</strong></div>
    <div class="padding border-bottom">
    <form method="get" action="users.php">
      <ul class="search" style="padding-left:10px;">  
        <li>user name：</li>
        <li>
          <input type="text" placeholder="Please enter search keywords" name="name" value="<?php if(!empty($_GET['name'])){echo $_GET['name'];} ?>" class="input" style="width:250px; line-height:17px;display:inline-block" />
          <input type="submit" value="search" class="button border-main icon-search">
        </li>
      </ul>
      </form>
    </div>
    <table class="table table-hover text-center">
      <tr>
        <th width="120">ID</th>
        <th>user name</th>       
        <th>Registration time</th>
  
        <th>operation</th>       
      </tr>  
      <?php
        //Connect to database
        include('../../config/dbconfig.php'); 

        //Accept search criteria information
        $wherelist = array();//Search criteria to database
        $urllist = array();//The search condition gives the URL the status maintenance

        //Determine whether the search criteria exist
        if(!empty($_GET['name'])){
            $wherelist[] = " username like '%".$_GET['name']."%'";
            $urllist[] = "name={$_GET['name']}";
        }

        //Splicing search statements
        $where = "";
        $url = "";
        if(count($wherelist)>0){
          $where =  " where ".implode(' and ', $wherelist);
          $url = implode('&', $urllist);
        }

         // Paging settings
        $page = !empty($_GET['p']) ? $_GET['p'] : 1 ;//Specific page number
        $pagesize = 10;//Number of items per page
        $maxrow = 0;//How many messages are there
        $maxpage = 0;//How many pages are displayed

        //  How many messages are there
        $sql = "select id from members ".$where;
        $result = mysqli_query($link,$sql) or die('Database operation failed：'.mysqli_error($link));
        $maxrow = mysqli_num_rows($result);

        //  How many pages are there altogether 
        $maxpage = ceil($maxrow/$pagesize);  //Ceil is a rounding function

        //  Judge the validity of the page number
        if($page>$maxpage){
          $page = $maxpage;
        }
        if($page<1){
          $page = 1;
        }
        
        // Write SQL statement
        $limit = " limit ".($page-1)*$pagesize.",".$pagesize;
          //Splicing search and paging function
          $sql = "select * from members ".$where.'order by registertime desc '.$limit;
          $result = mysqli_query($link,$sql) or die('Database operation failed：'.mysqli_error($link));
          //Display the data in the table
          $index = 1;
          while($row = mysqli_fetch_assoc($result)){
            echo "<tr>
              <td>".(($page-1)*$pagesize+$index++)."</td>
              <td>{$row['username']}</td>
              <td>{$row['registertime']}</td>
            
              <td><div class=\"button-group\"> 
                <a class=\"button border-main\" href=\"javascript:doEdit({$row['id']})\"><span class=\"icon-edit\"></span> Password Reset</a> 
                <a class=\"button border-red\" href=\"javascript:del({$row['id']})\"><span class=\"icon-trash-o\"></span> delete</a> </div></td>
            </tr>";
            
          }
        ?> 
      <tr>
        <td colspan="8"><div class="pagelist"> 
          <?php
             echo "<a href='users.php?p=1&{$url}'>home page</a>";
              echo "<a href='users.php?p=".($page-1)."&{$url}'>previous page</a>";
              echo "<span class='current'>total:{$maxrow} {$page}/{$maxpage} </span>";
              echo "<a href='users.php?p=".($page+1)."&{$url}'>next page</a>";
              echo "<a href='users.php?p={$maxpage}&{$url}'>Last page</a>";
        ?>
        </div>
        </td>
      </tr>
    </table>
  </div>
<script type="text/javascript">
function del(id){
  if(confirm("Are you sure you want to delete it?")){
      window.location.href='action.php?a=del&id='+id;
  }
}
function doEdit(id){
  if(confirm("Are you sure you want to reset your password?")){
      window.location.href='action.php?a=reset&id='+id;   
  }
}
</script>
</body>
</html>