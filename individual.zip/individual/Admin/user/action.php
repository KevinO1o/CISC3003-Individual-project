<?php
	include("../../config/dbconfig.php");

	switch($_GET['a']){
		case 'del':
			$sql = "delete from members where id=".$_GET['id'];
			$result = mysqli_query($link,$sql) or die('Database operation failed：'.mysqli_error($link));
			if(mysqli_affected_rows($link)){
				echo "<script>alert('delete successful！');window.location.href='users.php'</script>";
			}else{
				echo "<script>alert('delete failed！');history.go(-1)</script>";
			}
			break;
		case 'reset':
			$newpass = '123456';
			$sql = "update members set password='$newpass' where id=".$_GET['id'];
			$result = mysqli_query($link,$sql) or die('Database operation failed：'.mysqli_error($link));
			if($result){
				echo "<script>alert('Password Reset successful！new password：123456');window.location.href='users.php'</script>";
			}else{
				echo "<script>alert('Password reset failed！');history.go(-1)</script>";
			}
			break;
	}
	//关闭数据库 
	mysqli_close($link);