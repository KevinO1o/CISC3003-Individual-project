<?php 
  if (!isset($_SESSION)) {
      session_start();
  }
  if(!isset($_SESSION['admin_users'])){
    echo "<script>window.location.href='./login/login.php'</script>";
    exit;
  }
?>
<!DOCTYPE html>
<html lang="zh-cn">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <meta name="renderer" content="webkit">
    <title>Management System</title>

    <link rel="stylesheet" href="./include/css/pintuer.css">
    <link rel="stylesheet" href="./include/css/admin.css">
    <script src="./include/js/jquery.js"></script>   
</head>
<body style="background-color:#cccc99">
<div class="header bg-main">
  <div class="logo margin-big-left fadein-top">
    <h1>Management System</h1>
  </div>
  <div class="head-l">
    <a class="button button-little" href="../index.php" target="_blank"><span class="icon-home"></span> Homepage</a> &nbsp;&nbsp;
    <a class="button button-little bg-red" href="./login/logout.php"><span class="icon-power-off"></span> Log out</a> &nbsp;&nbsp;
    <span style="color: #fff;">Welcome，
    <?php
      if(isset($_SESSION['admin_users'])){
        echo $_SESSION['admin_users']['username'];
      }
    ?></span>
  </div>
</div>
<div class="leftnav">
  <div class="leftnav-title"><strong><span class="icon-list"></span>Menu list</strong></div>
  <h2><span class="icon-user"></span>Member management</h2>
  <ul style="display:block">
    <li><a href="./user/users.php" target="right"><span class="icon-caret-right"></span>Member</a></li>
  </ul>

  <h2><span class="icon-th-list"></span>Classified management</h2>
  <ul style="display:block">
    <li><a href="./type/type_list.php" target="right"><span class="icon-caret-right"></span>Classified</a></li>
    <li><a href="./type/type_add.php" target="right"><span class="icon-caret-right"></span>Add category</a></li>
  </ul> 

  <h2><span class="icon-file-o"></span>Commodity management</h2>
  <ul style="display:block">
    <li><a href="./goods/good_list.php" target="right"><span class="icon-caret-right"></span>Commodity management</a></li>
    <li><a href="./goods/good_add.php" target="right"><span class="icon-caret-right"></span>Add item</a></li>
  </ul> 

  <h2><span class="icon-file-o"></span>Order management</h2>
  <ul style="display:block">
    <li><a href="order/order_list.php" target="right"><span class="icon-caret-right"></span>Order management</a></li>
  </ul> 

  <h2><span class="icon-list-alt"></span>Custom list</h2>
  <ul style="display:block">
    <li><a href="message/list.php" target="right"><span class="icon-caret-right"></span>Custom list</a></li>
  </ul>  

  <h2><span class="icon-gear"></span>Change Password</h2>
  <ul style="display:block">
    <li><a href="login/pass.php" target="right"><span class="icon-caret-right"></span>Change Password</a></li>
  </ul>  

</div>
<script type="text/javascript">
$(function(){
  $(".leftnav h2").click(function(){
	  $(this).next().slideToggle(200);	
	  $(this).toggleClass("on"); 
  })
  $(".leftnav ul li a").click(function(){
	    $("#a_leader_txt").text($(this).text());
  		$(".leftnav ul li a").removeClass("on");
		$(this).addClass("on");
  })
  $(".bread .icon-home").click(function(){
      $("#a_leader_txt").text('网站信息');
  })
});
</script>
<ul class="bread">
  <li><a href="info.php" target="right" class="icon-home"> Home</a></li>
  <li><a href="##" id="a_leader_txt">Website information</a></li>
</ul>
<div class="admin">
  <iframe scrolling="auto" rameborder="0" src="info.php" name="right" width="100%" height="100%"></iframe>
</div>
</body>
</html>