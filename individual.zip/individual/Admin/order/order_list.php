<?php 
  if (!isset($_SESSION)) {
      session_start();
  }
  if(!isset($_SESSION['admin_users'])){
    echo "<script>window.location.href='../login/login.php'</script>";
    exit;
}
?>
<!DOCTYPE html>
<html lang="zh-cn">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <meta name="renderer" content="webkit">
    <title></title>  
    <link rel="stylesheet" href="../include/css/pintuer.css">
    <link rel="stylesheet" href="../include/css/admin.css">
    <script src="../include/js/jquery.js"></script>
    <script src="../include/js/pintuer.js"></script>  
</head>
<body>
  <div class="panel admin-panel">
    <div class="panel-head"><strong class="icon-reorder"> Order information</strong></div>
    <div class="padding border-bottom">
    <form method="get" action="order_list.php">
      <ul class="search" style="padding-left:10px;">  
        <li>order number：</li>
        <li>
          <input type="text" placeholder="Please enter search keywords" name="orderno" value="<?php if(!empty($_GET['orderno'])){echo $_GET['orderno'];} ?>" class="input" style="width:250px; line-height:17px;display:inline-block" />
          <input type="submit" value="search" class="button border-main icon-search">
        </li>
      </ul>
      </form>
    </div>
    <table class="table table-hover text-center">
      <tr>
        <th>order number</th>
        <th>Order content</th>
        <th>Order Price</th> 
        <th>Order name</th> 
   
        <th>Order time</th>
      
      </tr>  
      <?php
        //Connect to database
        include('../../config/dbconfig.php'); 
        //Accept search criteria information
        $wherelist = array();//Search criteria to database
        $urllist = array();//The search condition gives the URL the status maintenance

        //Determine whether the search criteria exist
        if(!empty($_GET['orderno'])){
            $wherelist[] = " order_id like '%".$_GET['orderno']."%'";
            $urllist[] = "orderno={$_GET['orderno']}";
        }

        //Splicing search statements
        $where = "";
        $url = "";
        if(count($wherelist)>0){
          $where =  " where ".implode(' and ', $wherelist);
          $url = implode('&', $urllist);
        }

        // Paging settings
        $page = !empty($_GET['p']) ? $_GET['p'] : 1 ;//Specific page number
        $pagesize = 10;//Number of items per page
        $maxrow = 0;//How many messages are there
        $maxpage = 0;//How many pages are displayed

        //  How many messages are there
        $sql = "select order_id from `order` ".$where;
        $result = mysqli_query($link,$sql) or die('Database operation failed：'.mysqli_error($link));
        $maxrow = mysqli_num_rows($result);

        //  How many pages are there altogether 
        $maxpage = ceil($maxrow/$pagesize);  //Ceil is a rounding function

        //  Judge the validity of the page number
        if($page>$maxpage){
          $page = $maxpage;
        }
        if($page<1){
          $page = 1;
        }
        
        // Write SQL statement
        $limit = " limit ".($page-1)*$pagesize.",".$pagesize;
          //Splicing search and paging function
          $sql = "select * from `order` ".$where.'order by addtime desc '.$limit;
          $result = mysqli_query($link,$sql) or die('Database operation failed：'.mysqli_error($link));
          //Display the data in the table
          while($row = mysqli_fetch_assoc($result)){
            $goodsInfo = json_decode($row['content'],true);
            $infoStr = '';
            foreach ($goodsInfo as $key=>$info) {
              $infoStr .= '['.$info['gid'].']'.$info['gname'].'_￥'.$info['price'].' x'.$info['num'].'<br>';
            }
            $infoStr = rtrim($infoStr,'<br>');
        ?>

            <tr>
              <td><?php echo $row['order_id'];?></td>
              <td><?php echo $infoStr;?></td>
              <td>￥<?php echo $row['total_price'];?></td>
              <td><?php echo $row['username'];?></td>
              <td><?php echo $row['addtime'];?></td>
           
            </tr>
        <?php } ?> 
      <tr>
        <td colspan="8"><div class="pagelist"> 
          <?php
            echo "<a href='order_list.php?p=1&{$url}'>home page</a>";
            echo "<a href='order_list.php?p=".($page-1)."&{$url}'>previous page</a>";
            echo "<span class='current'>total:{$maxrow} {$page}/{$maxpage} page</span>";
            echo "<a href='order_list.php?p=".($page+1)."&{$url}'>next page</a>";
            echo "<a href='order_list.php?p={$maxpage}&{$url}'>Last page</a>";
          ?>
        </div>
        </td>
      </tr>
    </table>
  </div>
<script type="text/javascript">
function del(id,img){
  if(confirm("Are you sure you want to delete it?")){
    window.location.href='good_action.php?a=del&gid='+id+'&img='+img;
  }
}
</script>
</body>
</html>