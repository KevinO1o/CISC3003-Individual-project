<?php 
  include("../config/dbconfig.php");
  if(!isset($_SESSION['admin_users'])){
    echo "<script>window.location.href='../login/login.php'</script>";
    exit;
}
?>
<!DOCTYPE html>
<html lang="zh-cn">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <meta name="renderer" content="webkit">
    <title>Website information</title>
    <link rel="stylesheet" href="./include/css/pintuer.css">
    <link rel="stylesheet" href="./include/css/admin.css">
    <script src="./include/js/jquery.js"></script>
    <script src="./include/js/pintuer.js"></script>  
</head>
<body>
<div class="panel admin-panel">
  <div class="panel-head"><strong><span class="icon-pencil-square-o"></span> Website information</strong></div>
  <div class="body-content">
      <div class="form-group" style="padding-left: 20px;">
        <div class="label">
          <label>Use domain name：</label>
          <span class="info"> <?php echo $_SERVER['HTTP_HOST'];?></span>
        </div>
      </div>
      
      <div class="form-group" style="padding-left: 20px;">
        <div class="label">
          <label>MySQL version：</label>
          <span class="info"> <?php  echo mysqli_get_server_info($link); ?></span>
        </div>
      </div>
  </div>
</div>
</body></html>