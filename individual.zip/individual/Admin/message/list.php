<?php 
  if (!isset($_SESSION)) {
      session_start();
  }
  if(!isset($_SESSION['admin_users'])){
    header('Location:./login.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="zh-cn">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <meta name="renderer" content="webkit">
    <title></title>  
    <link rel="stylesheet" href="../include/css/pintuer.css">
    <link rel="stylesheet" href="../include/css/admin.css">
    <script src="../include/js/jquery.js"></script>
    <script src="../include/js/pintuer.js"></script>  
</head>
<body>
  <div class="panel admin-panel">
    <div class="panel-head"><strong class="icon-reorder"> Customized information</strong></div>
    <div class="padding border-bottom">
    <form method="get" action="list.php">
      <ul class="search" style="padding-left:10px;">  
        <li>user name：</li>
        <li>
          <input type="text" placeholder="Please enter search keywords" name="name" value="<?php if(!empty($_GET['name'])){echo $_GET['name'];} ?>" class="input" style="width:250px; line-height:17px;display:inline-block" />
          <input type="submit" value="search" class="button border-main icon-search">
        </li>
      </ul>
      </form>
    </div>
    <table class="table table-hover text-center">
      <tr>
        <th width="120">ID</th>
        <th>user name</th>       
        <th>Trade name</th>
        <th>Customization details</th>
        <th>time</th>       
      </tr>  
      <?php
        //Connect to database
        include('../../config/dbconfig.php'); 

        //Accept search criteria information
        $wherelist = array();//Search criteria to database
        $urllist = array();//The search condition gives the URL the status maintenance

        //Determine whether the search criteria exist
        if(!empty($_GET['name'])){
            $wherelist[] = " name like '%".$_GET['name']."%'";
            $urllist[] = "name={$_GET['name']}";
        }

        //Splicing search statements
        $where = "";
        $url = "";
        if(count($wherelist)>0){
          $where =  " where ".implode(' and ', $wherelist);
          $url = implode('&', $urllist);
        }

                  // Paging settings
        $page = !empty($_GET['p']) ? $_GET['p'] : 1 ;//Specific page number
        $pagesize = 10;//Number of items per page
        $maxrow = 0;//How many messages are there
        $maxpage = 0;//How many pages are displayed

        //  How many messages are there
        $sql = "select id from messages ".$where;
        $result = mysqli_query($link,$sql);
        $maxrow = mysqli_num_rows($result);

        //  How many pages are there altogether 
        $maxpage = ceil($maxrow/$pagesize);  //Ceil is a rounding function

        //  Judge the validity of the page number
        if($page>$maxpage){
          $page = $maxpage;
        }
        if($page<1){
          $page = 1;
        }
        
        // Write SQL statement
        $limit = " limit ".($page-1)*$pagesize.",".$pagesize;
          //Splicing search and paging function
          $sql = "select * from messages ".$where.'order by dtTime desc '.$limit;
          $result = mysqli_query($link,$sql);
          //Display the data in the table
          $index = 1;
          while($row = mysqli_fetch_assoc($result)){
            echo "<tr>
              <td>{$index}</td>
              <td>{$row['name']}</td>
              <td>{$row['title']}</td>
              <td>{$row['content']}</td>
              <td>{$row['dtTime']}</td>
              </tr>";
              $index++;
          }
        ?> 
      <tr>
        <td colspan="8"><div class="pagelist">
        <?php
             echo "<a href='list.php?p=1&{$url}'>home page</a>";
              echo "<a href='list.php?p=".($page-1)."&{$url}'>previous page</a>";
              echo "<span class='current'>total:{$maxrow} {$page}/{$maxpage} page</span>";
              echo "<a href='list.php?p=".($page+1)."&{$url}'>next page</a>";
              echo "<a href='list.php?p={$maxpage}&{$url}'>Last page</a>";
        ?>
        </div>
        </td>
      </tr>
    </table>
  </div>
</body>
</html>