-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- 主机： localhost
-- 生成日期： 2023-09-06 14:57:00
-- 服务器版本： 5.7.26
-- PHP 版本： 7.3.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 数据库： `glamify`
--
CREATE DATABASE IF NOT EXISTS `glamify` DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci;
USE `glamify`;

-- --------------------------------------------------------

--
-- 表的结构 `admin`
--

DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin` (
  `username` varchar(20) COLLATE utf8_unicode_ci NOT NULL COMMENT '用户名',
  `pass` varchar(16) COLLATE utf8_unicode_ci NOT NULL COMMENT '密码'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- 转存表中的数据 `admin`
--

INSERT INTO `admin` (`username`, `pass`) VALUES
('admin', 'admin888');

-- --------------------------------------------------------

--
-- 表的结构 `cart`
--

DROP TABLE IF EXISTS `cart`;
CREATE TABLE `cart` (
  `cid` int(11) NOT NULL COMMENT '自增id',
  `username` varchar(30) COLLATE utf8_unicode_ci NOT NULL COMMENT '用户id',
  `gid` int(11) NOT NULL COMMENT '商品id',
  `num` int(11) NOT NULL COMMENT '数量'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='购物车';

--
-- 转存表中的数据 `cart`
--

INSERT INTO `cart` (`cid`, `username`, `gid`, `num`) VALUES
(25, 'test1', 12, 1),
(24, 'test1', 18, 3),
(26, 'test', 12, 25),
(28, 'WANGXINYI', 15, 1),
(29, 'WANGXINYI', 14, 1),
(30, 'WANGXINYI', 19, 1),
(31, 'test', 15, 2),
(32, 'test', 11, 1);

-- --------------------------------------------------------

--
-- 表的结构 `goods`
--

DROP TABLE IF EXISTS `goods`;
CREATE TABLE `goods` (
  `gid` int(11) NOT NULL COMMENT '商品编号',
  `tid` int(11) NOT NULL COMMENT '商品分类',
  `gname` varchar(255) NOT NULL COMMENT '商品名称',
  `price` float NOT NULL COMMENT '商品价格',
  `pic` varchar(100) NOT NULL COMMENT '封面图',
  `content` longtext NOT NULL COMMENT '商品详情',
  `sort` int(11) NOT NULL COMMENT '排序号',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态【1:上架,0:已下架】',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='商品表';

--
-- 转存表中的数据 `goods`
--

INSERT INTO `goods` (`gid`, `tid`, `gname`, `price`, `pic`, `content`, `sort`, `status`, `addtime`) VALUES
(11, 1, 'Extra Moisturizing Type', 40, '1682726430646081.jpg', '<p>The precious red ginseng grown in the fertile soil and climate of Changbai Mountain for 6 years has several times stronger efficacy than ordinary ginseng. Through scientific extraction of red ginseng essence, the skin nourishing activity of red ginseng is well preserved.</p>', 10, 1, '2023-04-25 01:23:21'),
(12, 1, 'Olive lipstick', 45, '1682726741759651.jpg', '<p>According to the unique shape of the Pipa instrument, extract the point, line and surface elements formed by the core, approaching the smooth Strict selection of high-quality and tender olives from the Andalusian planting families in Spain,Artificial picking does not destroy the original beauty ingredients in olives, but only gathers the \"flower of olive oil\" that naturally drips,Can form a natural sebum film on the lips,Always protect delicate lips.</p>', 9, 1, '2023-04-25 01:25:47'),
(13, 1, 'Velvet Skin Coat', 25, '1682726957849461.jpg', '<p>DHC Pre Makeup Pore Leveling Cream is a semi transparent gel with a soft and smooth touch, which can smooth the uneven surface of the skin, cover annoying fine lines and pores, and give the skin a velvet like smooth texture.<br>In addition, it can also endow the skin with natural luster, at the same time, it can improve the smoothness of liquid foundation makeup, closely fit the skin, improve makeup removal, maintain the smooth makeup effect of foundation make-up and the beauty of newly applied makeup, and create bright skin without concave and convex.</p>', 8, 1, '2023-04-25 01:26:14'),
(14, 1, 'Set up powder', 40, '1682727189153149.jpg', '<p>AcThis product is a special powder puff for DHC firming, rejuvenating, moisturizing and makeup setting powder.Made with flocking processing, the surface is soft and has suitable powder extraction power, which can make the makeup effect more lightweight and comfortable.Both sides can be used.</p>', 7, 1, '2023-04-25 01:27:07'),
(15, 1, '4-color eye shadow', 39, '1682727803435938.jpg', '<p>DHC Colorstay Starlight 4-color eye shadow is not limited to creating a single tone, but is designed to interpret the eye makeup with a deep aesthetic feeling. Give the eyes an impressive \"color\", bright \"light\", and a \"three-dimensional sense\" brought by shadows. It can also present a natural and layered \"depth\", shaping charming eye makeup. No need for complex techniques! With this 4-color eye shadow plate, you can easily complete beautiful eye makeup.<br>Although in powder form, the texture is smooth and gives off a natural luster and radiance, which not only gives the eyes beautiful colors, but also takes care of the fragile eyelid skin in makeup. Applying makeup also takes care of the skin.</p>', 6, 1, '2023-04-25 01:27:45'),
(16, 3, 'eye gel', 16, '1682728302737414.jpg', '<p>The next morning after staying up late or experiencing excessive fatigue, the skin around the eyes will lose elasticity and luster, giving the impression of lethargy. DHC Refreshing&amp;Brightening Eye gel contains anhydrous caffeine and fragrant tea herb essence, which can cool and astringe the eye. In addition, add moisturizing ingredients such as licorice essence, hyaluronic acid, cucumber essence, etc., to keep moisture and improve the fine lines caused by drying. Good moisturizing effect can protect delicate eye skin from dryness and invasion, presenting a glossy appearance. It feels refreshing and comfortable to use, and can astringe the eye area. It is recommended that you use DHC Moisturizing&amp;Brightening Eye gel to soothe the tired eye skin after using the computer for a long time.</p>', 5, 1, '2023-04-25 01:28:12'),
(17, 3, 'Beauty liquid', 56, '1682728494250727.jpg', '<p>Half-empty and half-solid shapes, intermDHC Moisturizing and Wrinkle Leveling Beauty Lotion is a beauty solution designed for dryness and fine lines. Simply add makeup water and use it to improve dryness and enhance elasticity. A clear texture like a gel, without giving the skin a sticky feeling. Maintain a sense of moisture, allowing the skin to feel unique fullness and fullness.</p>', 4, 1, '2023-04-25 01:35:28'),
(18, 7, 'Refreshing lotion', 42, '1682728620653013.jpg', '<p>Appearance DHC Firming and Revitalizing Makeup Water is added with coDHC Anti acne Repair Refreshing lotion added with salicylic acid has the function of cleaning skin and softening cutin, leading to clear, tender, smooth and beautiful skin. Excellent ductility and a refreshing feeling of use. Improve skin condition and provide gentle skincare.Care for skin prone to acne, providing a refreshing and oily feel. Recommended for use throughout the entire series.</p>', 3, 1, '2023-04-25 01:37:57'),
(19, 4, 'Anti wrinkle milk', 39, '1682729041425610.jpg', '<p>Appearance design of belt Concentrate on caring for issues such as insufficient elasticity and loose pores. In addition, it also adds olive essence oil, placental protein and other skin beautifying ingredients. Good moisturizing effect helps maintain delicate and youthful skin tone. A soft and moisturizing texture with excellent ductility, which provides a smooth skin feel after application. Improve the aging marks of the skin, guide it to become full, elastic, and beautiful.</p>', 2, 1, '2023-04-25 01:39:01');

-- --------------------------------------------------------

--
-- 表的结构 `members`
--

DROP TABLE IF EXISTS `members`;
CREATE TABLE `members` (
  `id` int(11) NOT NULL COMMENT '自增id',
  `username` varchar(50) COLLATE utf8_unicode_ci NOT NULL COMMENT '用户名',
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT '密码',
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `registertime` datetime NOT NULL COMMENT '注册时间'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- 转存表中的数据 `members`
--

INSERT INTO `members` (`id`, `username`, `password`, `email`, `registertime`) VALUES
(1, 'test', 'test', '', '2023-04-18 17:05:13'),
(3, 'test1', 'test', 'test@qq.com', '2023-04-20 15:54:49'),
(4, 'WANGXINYI', '123456', 'WANGXINYI@gmail.com', '2023-04-29 11:09:16');

-- --------------------------------------------------------

--
-- 表的结构 `messages`
--

DROP TABLE IF EXISTS `messages`;
CREATE TABLE `messages` (
  `id` int(11) NOT NULL COMMENT 'id自增',
  `name` varchar(20) COLLATE utf8_unicode_ci NOT NULL COMMENT '姓名',
  `title` varchar(100) COLLATE utf8_unicode_ci NOT NULL COMMENT '标题',
  `content` text COLLATE utf8_unicode_ci NOT NULL COMMENT '内容',
  `dtTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- 转存表中的数据 `messages`
--

INSERT INTO `messages` (`id`, `name`, `title`, `content`, `dtTime`) VALUES
(25, 'test', 'Water tender set', 'Price：$200', '2023-09-06 06:54:40'),
(23, 'test', 'Pink Honey Set', 'Price：$120', '2023-09-06 06:50:20'),
(22, 'test', 'Summer Skincare', 'Price：$100', '2023-09-06 06:49:20');

-- --------------------------------------------------------

--
-- 表的结构 `order`
--

DROP TABLE IF EXISTS `order`;
CREATE TABLE `order` (
  `oid` int(11) NOT NULL COMMENT '自增id',
  `order_id` varchar(16) COLLATE utf8_unicode_ci NOT NULL COMMENT '订单号',
  `username` varchar(30) COLLATE utf8_unicode_ci NOT NULL COMMENT '账号',
  `total_price` float NOT NULL COMMENT '总价格',
  `content` text COLLATE utf8_unicode_ci NOT NULL COMMENT '商品信息',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '下单时间'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='订单 表';

--
-- 转存表中的数据 `order`
--

INSERT INTO `order` (`oid`, `order_id`, `username`, `total_price`, `content`, `addtime`) VALUES
(11, '2023042950985657', 'WANGXINYI', 40, '[{\"gid\":\"11\",\"gname\":\"Extra Moisturizing Type\",\"price\":\"40\",\"pic\":\"1682726430646081.jpg\",\"num\":\"1\"}]', '2023-04-29 03:12:50');

-- --------------------------------------------------------

--
-- 表的结构 `type`
--

DROP TABLE IF EXISTS `type`;
CREATE TABLE `type` (
  `tid` int(11) NOT NULL COMMENT '分类id',
  `tname` varchar(20) COLLATE utf8_unicode_ci NOT NULL COMMENT '分类名称',
  `sort` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='分类表';

--
-- 转存表中的数据 `type`
--

INSERT INTO `type` (`tid`, `tname`, `sort`) VALUES
(1, 'Facial Cleanser', 10),
(2, 'Eye', 101),
(3, 'Toner', 2),
(4, 'perfume', 102),
(7, 'lip gloss', 100);

--
-- 转储表的索引
--

--
-- 表的索引 `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`username`);

--
-- 表的索引 `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`cid`),
  ADD UNIQUE KEY `username_gid` (`username`,`gid`);

--
-- 表的索引 `goods`
--
ALTER TABLE `goods`
  ADD PRIMARY KEY (`gid`);

--
-- 表的索引 `members`
--
ALTER TABLE `members`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- 表的索引 `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`);

--
-- 表的索引 `order`
--
ALTER TABLE `order`
  ADD PRIMARY KEY (`oid`),
  ADD UNIQUE KEY `order_id` (`order_id`);

--
-- 表的索引 `type`
--
ALTER TABLE `type`
  ADD PRIMARY KEY (`tid`);

--
-- 在导出的表使用AUTO_INCREMENT
--

--
-- 使用表AUTO_INCREMENT `cart`
--
ALTER TABLE `cart`
  MODIFY `cid` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增id', AUTO_INCREMENT=33;

--
-- 使用表AUTO_INCREMENT `goods`
--
ALTER TABLE `goods`
  MODIFY `gid` int(11) NOT NULL AUTO_INCREMENT COMMENT '商品编号', AUTO_INCREMENT=21;

--
-- 使用表AUTO_INCREMENT `members`
--
ALTER TABLE `members`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增id', AUTO_INCREMENT=5;

--
-- 使用表AUTO_INCREMENT `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'id自增', AUTO_INCREMENT=26;

--
-- 使用表AUTO_INCREMENT `order`
--
ALTER TABLE `order`
  MODIFY `oid` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增id', AUTO_INCREMENT=12;

--
-- 使用表AUTO_INCREMENT `type`
--
ALTER TABLE `type`
  MODIFY `tid` int(11) NOT NULL AUTO_INCREMENT COMMENT '分类id', AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
