<ul class="navbar-nav bg-nav" style="width:100%">
    <li class="nav-item"><a class="nav-link" href="index.php">HOME</a></li>
    <li class="nav-item"><a class="nav-link" href="about.php">ABOUT</a></li>
    <li class="nav-item"><a class="nav-link" href="product.php">PRODUCT</a></li>
    <li class="nav-item"><a class="nav-link" href="customization.php">Customization</a></li>
    <li class="nav-item">  <li class="nav-item">
        <?php
        if (!isset($_SESSION)) {
            session_start();
        }
        if(isset($_SESSION['home_user'])){ ?>
            <span class="login nav-link">Hello，<?php echo $_SESSION['home_user'];?> </span>
        <?php  }else{ ?>
            <a href='reg.html?a=login' class="nav-link">Login/Register</a>
        <?php } ?>
    </li></li>
</ul>