<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>ABOUT</title>
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="font/font-awesome/css/font-awesome.min.css">
<link rel="stylesheet" href="css/animate.css">
<link rel="stylesheet" type="text/css" href="css/style.css">
<script src="js/jquery.min.js"></script>
<script src="js/wow.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
</head>

<body>
<div class="container-fluid">
  <header class="bg">
    <nav class="navbar navbar-expand-sm navbar-dark container"> 
      <!-- Brand --> 
      <a class="navbar-brand" href="#"></a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar"><span
                    class="navbar-toggler-icon"></span></button>
      <!-- Links -->
      <div class="collapse navbar-collapse" id="collapsibleNavbar">
        <?php include('header.php');?>
      </div>
    </nav>
  </header>
</div>
<div class="container-fluid bgwhite">
  <h1 class="m100 text-center">ABOUT</h1>
  <div class="row  padding3">
    <div class="col-lg-4 text-center"><img src="img/about1.png" class="img-fluid"  alt=""></div>
    <div class="col-lg-8 desc" >
      <h3> Who We Are?</h3>
      <p> <strong>Beauty, to me, is about being comfortable in your own skin</strong><br>
        <br>
        Glimify is a leading online platform that offers a wide range of high-quality cosmetics and beauty products. Our website provides customers with easy access to some of the best beauty brands, ensuring that they can find everything they need in one convenient location. We are dedicated to offering our customers an exceptional shopping experience, and our commitment to quality, affordability, and customer satisfaction is unmatched. </p>
      <p> Generators on the Internet tend to repeat predefined chunks as necessary, maki this the first true generator on the Internet.
      <p> 
    </div>
  </div>
  <div class="row bg-light padding13">
    <div class="col-lg-8 desc" >
      <h3>Our Mission</h3>
      <p> <strong>We Are A Zolkany Focused On Delivering Product</strong><br>
        <br>
        At Glamify, our mission is to empower everyone to look and feel their best. We believe that beauty is more than skin-deep, and that everyone deserves to feel confident and comfortable in their own skin. That's why we work tirelessly to source only the best cosmetics  products, ensuring that our customers can enjoy the benefits of high-quality, effective, and safe products that enhance their natural beauty. We are committed to promoting sustainable and ethical beauty practices. Our mission is to help our customers shine from the inside out, and we are proud to be a trusted source of inspiration and empowerment in the cosmetics industry. </p>
      <ul class="d-flex items" >
        <li>Better Quality</li>
        <li>Secure Payment</li>
      </ul>
      <ul class="d-flex items" >
        <li>Quality Materials</li>
        <li>Simple Retaurn</li>
      </ul>
      <ul class="d-flex items" >
        <li>Good Service</li>
        <li>Online Support</li>
      </ul>
      <ul class="d-flex items" >
        <li>In time Delivery</li>
        <li>Creative Team</li>
      </ul>
    </div>
    <div class="col-lg-4 text-center"><img src="img/about2.jpg" class="img-fluid"  alt=""></div>
  </div>
</div>
<div class="link container">
  <div class="row">
    <div class="col-sm-5">
      <h2>Quick Links</h2>
      <?php include('link.php');?>
    </div>
    <div class="col-sm-7">
      <h2>Contact Information</h2>
      <ol class="list-unstyled">
        <li class="py-2"> Address：2063 RM, FE4，BD,DAXUEDAMALU ROAD,UNIVERSITY OF MACAU</li>
        <li class="py-2">Tel：+ 447419410529</li>
        <li class="py-2">Myblog-Summerproject：<a href="#">Myblog-Summerproject</a></li>
        <li class="py-2">Email：abc12345678@yahu.com</li>
        <li class="text-right py-2"><a href="https://twitter.com/edinburghuni" target="_blank"><i
                        class="fa fa-twitter-square"></i></a><a href="https://m.facebook.com/ECA.edinburgh/"
                                                                target="_blank"><i class="fa fa-facebook-square"
                                                                                   aria-hidden="true"></i></a><a
                        href="https://www.instagram.com/changwang670/" target="_blank"><span
                        class="fa fa-instagram"></span></a></li>
      </ol>
    </div>
  </div>
</div>
<footer>
  <div class="text-center p-2 text-light">CISC3003 DC12824 ZENG JIANHENG -  <i
            class="glyphicon glyphicon-heart"></i></div>
</footer>

<script>

    if (!(/msie [6|7|8|9]/i.test(navigator.userAgent))) {

        new WOW().init();

    }

</script>
</body>
</html>
