<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>PRODUCT</title>
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="font/font-awesome/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="css/style.css">
<script src="js/jquery.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
</head>

<body>
<div class="container-fluid">
  <header  class="bg">
    <nav class="navbar navbar-expand-sm navbar-dark container"> 
      <!-- Brand --> 
      <a class="navbar-brand" href="#"></a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar"> <span class="navbar-toggler-icon"></span> </button>
      <!-- Links -->
      <div class="collapse navbar-collapse" id="collapsibleNavbar">
          <?php include('header.php');?>
      </div>
    </nav>
  </header>
  

<div class="container">
<h1 class="m100 text-center">PRODUCT</h1>
<div class="row inner-product " >
    <?php
     include('config/dbconfig.php');

    $sql = "select * from goods order by sort desc,addtime desc";
    $result = mysqli_query($link,$sql) or die('Database operation failed：'.mysqli_error($link));
    //Display the data in the table
    while($row = mysqli_fetch_assoc($result)){
    echo "<div class='col-lg-4 col-md-6'><a href='product-show.php?id={$row['gid']}'><img src='admin/include/uploads/{$row['pic']}'  class='img-fluid' ></a>
<h5><a href='product-show.php?id={$row['gid']}'>{$row['gname']}<br><small>Price：$ {$row['price']}</small><br><span>BUY NOW ></span></a></h5></div>";
    }
    ?>

</div></div>
<div class="bgpink">
 <div class="inner-link container ">
    <div class="row">
      <div class="col-sm-5">
        <h2>Quick Links</h2>
          <?php include('link.php');?>
      </div>
      <div class="col-sm-7">
        <h2>Contact Information</h2>
        <ol class="list-unstyled">
          <li  class="py-2"> Address：2063 RM, FE4，BD,DAXUEDAMALU ROAD,UNIVERSITY OF MACAU</li>
          <li class="py-2">Tel：+ 447419410529</li>
          <li class="py-2">Myblog-Summerproject：<a href="#">Myblog-Summerproject</a></li>
          <li class="py-2">Email：abc12345678@yahu.com</li>
          <li class="text-right py-2"><a href="https://twitter.com/edinburghuni" target="_blank"><i class="fa fa-twitter-square"></i></a><a href="https://m.facebook.com/ECA.edinburgh/" target="_blank"><i class="fa fa-facebook-square" aria-hidden="true"></i></a><a href="https://www.instagram.com/changwang670/" target="_blank"><span class="fa fa-instagram"></span></a></li>
        </ol>
      </div>
    </div>
  </div>
  </div>
  <footer>
    <div class="text-center p-2 text-light"> CISC3003 DC12824 ZENG JIANHENG<i class="
glyphicon glyphicon-heart"></i></div>
  </footer>
</div>
</body>
</html>
