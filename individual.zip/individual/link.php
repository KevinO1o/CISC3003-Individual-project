<ul class="list-unstyled">
  <li class="py-2"><a href="index.php" >Home</a></li>
  <li class="py-2"><a href="about.php">About</a></li>
  <li class="py-2" ><a href="product.php" >Product</a></li>
  <li class="py-2"><a href="customization.php">CUSTOMIZATION</a></li>
</ul>
