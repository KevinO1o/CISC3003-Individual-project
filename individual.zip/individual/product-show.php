<?php
include('config/dbconfig.php');
if (!isset($_GET['id'])) {
    echo "<script>window.history.go(-1)</script>";
}
?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>PRODUCT</title>
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="font/font-awesome/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="css/style.css">
<script src="js/jquery.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
</head>

<body>
<div class="container-fluid">
  <header  class="bg">
    <nav class="navbar navbar-expand-sm navbar-dark container"> 
      <!-- Brand --> 
      <a class="navbar-brand" href="#"></a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar"> <span class="navbar-toggler-icon"></span> </button>
      <!-- Links -->
      <div class="collapse navbar-collapse" id="collapsibleNavbar">
          <?php include('header.php');?>
      </div>
    </nav>
  </header>

    <?php
    $sql = "select * from goods where gid=".$_GET['id'];
    $result = mysqli_query($link,$sql) or die('Database operation failed：'.mysqli_error($link));
    $row = mysqli_fetch_assoc($result);
    if (!$row) {
        echo "<center style='padding-top:50px;'><h2>Error！</h2><center>";
        exit;
    }
    ?>
<div class="container">

<div class="row inner-product-show " >
<div class="col-md-6"><img src="admin/include/uploads/<?php echo $row['pic'];?>"  class="img-fluid" >
    <input type="hidden" id="gid" value="<?php echo $row['gid'];?>" />
</div>
<div class="col-md-6">
<h1><?php echo $row['gname'];?></h1>
<ul>
  <li ><strong class="price">Price：$<?php echo $row['price'];?></strong></li>
 <li><strong>product details：</strong><br>
     <?php echo $row['content'];?></li>

</ul>
<h5><a href="javascript:addShop()">Add to Cart ></a></h5>
</div>

</div></div>
<div class="bgpink">
 <div class="inner-link container ">
    <div class="row">
      <div class="col-sm-5">
        <h2>Quick Links</h2>
          <?php include('link.php');?>
      </div>
      <div class="col-sm-7">
        <h2>Contact Information</h2>
        <ol class="list-unstyled">
          <li  class="py-2"> Address：2063 RM, FE4，BD,DAXUEDAMALU ROAD,UNIVERSITY OF MACAU</li>
          <li class="py-2">Tel：+ 447419410529</li>
          <li class="py-2">Myblog-Summerproject：<a href="#">Myblog-Summerproject</a></li>
          <li class="py-2">Email：abc12345678@yahu.com</li>
          <li class="text-right py-2"><a href="https://twitter.com/edinburghuni" target="_blank"><i class="fa fa-twitter-square"></i></a><a href="https://m.facebook.com/ECA.edinburgh/" target="_blank"><i class="fa fa-facebook-square" aria-hidden="true"></i></a><a href="https://www.instagram.com/changwang670/" target="_blank"><span class="fa fa-instagram"></span></a></li>
        </ol>
      </div>
    </div>
  </div>
  </div>
  <footer>
    <div class="text-center p-2 text-light">CISC3003 DC12824 ZENG JIANHENG<i class="
glyphicon glyphicon-heart"></i></div>
  </footer>

</div>
<script>
    function addShop() {
        var gid = +$("#gid").val();
        window.location.href = 'action/action.php?a=cart&gid='+gid;
    }
</script>
</body>
</html>
